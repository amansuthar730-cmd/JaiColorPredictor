# Jai Color Predictor (Android Studio project)

This is an offline result tracker and historical frequency analyzer. It does NOT predict random outcomes, hack Jai Club, connect to accounts, or place bets.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync complete (Android Gradle Plugin 8.6.1; compile SDK 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

The project requires internet only for Gradle/SDK downloads during the build. The installed app itself works offline. No password, OTP, or account access is requested.
